"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         13, May
The last modified date: 18, May
Objective:      <<Building a class for analysing characters>>
                This class is used to analyse characters and punctuations. There
                are two primary functions in this class including analyse_characters and
                get_punctuation_frequency. The first one can analyse alphabets and numbers
                frequency and the second one will return back the punctuations frequency.
"""


from preprocessor_29286875 import Preprocessor
import pandas as pd


class CharacterAnalyser(object):
    """Building a class for analysing characters"""

    def __init__(self):
        """define a data structure for storing each character frequency"""
        self.dataframe = pd.DataFrame()  # initiate a data frame
        self.alpha_num_list = []  # initiate a list maintaining alphabets and numbers
        self.count = []  # initiate a list for counting all characters
        self.char_list = []  # initiate a list maintaining characters
        self.preprocessor = Preprocessor()  # initiate Preprocessor class
        # initiate the number of total texts
        self.total = len(self.preprocessor.get_tokenised_list())

    def __str__(self):
        """present the readable number of occurrences for each character"""

        # make a list with punctuations
        for char in self.char_list:  # each character in char_list
            if char not in self.alpha_num_list:  # check if exist in alpha_num_list
                self.alpha_num_list.append(char)  # if not, put into alpha_num_list

        # make the size of the count list as same as alpha_num_list
        self.count = [0] * len(self.alpha_num_list)

        for char in self.char_list:  # each character in char_list
            # count the occurrences of each character
            self.count[self.alpha_num_list.index(char)] += 1

        # construct a data frame make two lists readable
        dataframe = {'Characters': self.alpha_num_list, 'Characters Frequency': self.count}
        self.dataframe = pd.DataFrame(dataframe, index=self.alpha_num_list,
                                      columns=['Characters Frequency'])

        return print(self.dataframe)  # return a string

    def analyse_characters(self, tokenised_list):
        """analyse and count the occurrences for each of the characters"""

        no_punc_list = []  # create a list without punctuations

        #  make a list of alphabets and numbers
        alpha_num = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"  # string of alphabets and numbers
        self.alpha_num_list = list(alpha_num)  # make alpha_num become a list

        for each_word in tokenised_list:  # each word in tokenised_list
            # split each word to a single character & put into a temporary list
            temp_list = list(each_word)
            for each_char in temp_list:  # each character in temp_list
                # letters
                if each_char.isalpha():  # check if an alphabet
                    # if yes, make it upper and append into char_list
                    self.char_list.append(each_char.upper())
                # numerals and punctuations
                else:  # if not
                    self.char_list.append(each_char)  # append into char_list directly

        # make a list without punctuations
        for char in self.char_list:  # each character in char_list
            if char in self.alpha_num_list:  # check if exist in alpha_num_list
                if char not in no_punc_list:  # make a list without punctuations
                    no_punc_list.append(char)

        # make the size of no_punc_count as same as no_punc_list
        no_punc_count = [0] * len(no_punc_list)

        no_punc_list.sort()  # make the list readable (sort it)

        for each in self.char_list:  # each character in char_list
            if each in self.alpha_num_list:  # check if exist in alpha_num_list
                # count the occurrences of each character
                no_punc_count[no_punc_list.index(each)] += 1

        total_char = []
        # count the total number of characters (alphabet and number)
        for each in self.char_list:  # each character in char_list
            if each in self.alpha_num_list:  # check if each is alphabet or number
                total_char.append(each)  # if yes, append into total_char

        # create a relative frequency list divided with
        # the total number of characters (exclude punctustions)
        rela_no_punc = []  # create a list to put relative frequency result
        for each in no_punc_count:  # each character in no_punc_count
            rela_no_punc.append(100 * (each / len(total_char)))  # calculate and append to rela_no_punc

        # data structure for a list without punctuations
        dataframe = {'Characters': no_punc_list, 'Characters Frequency': rela_no_punc}
        self.dataframe = pd.DataFrame(dataframe)

        # return 2 lists
        return self.dataframe['Characters'], self.dataframe['Characters Frequency']

    def get_punctuation_frequency(self):
        """return only the frequency of all different punctuations"""

        punctuations = []  # create a list maintaining punctuations

        for each in self.char_list:  # each character in char_list
            if not each.isdigit() and not each.isalpha():  # check if not alphabets or numbers
                if each not in punctuations:  # check if in punctuations
                    punctuations.append(each)  # if not, append it into punctuations

        # make the size of punctuations_count as same as punctuations
        punctuations_count = [0] * len(punctuations)

        for each in self.char_list:  # each character in char_list
            if not each.isdigit() and not each.isalpha():  # check if not alphabets or numbers
                # count the occurrences of each punctuation
                punctuations_count[punctuations.index(each)] += 1

        total_punc = []
        # count the total number of punctuations
        for each in self.char_list:  # each character in char_list
            if not each.isdigit() and not each.isalpha():  # check if not alphabets or numbers
                total_punc.append(each)

        # create a relative frequency list divided with the total number of punctuations
        rela_punc = []
        for each in punctuations_count:  # each frequency in punctuations_count
            rela_punc.append(100 * (each / len(total_punc)))  # calculate and append to rela_punc

        dataframe = {'Punctuations': punctuations, 'Punctuations Frequency': rela_punc}
        self.dataframe = pd.DataFrame(dataframe)

        return self.dataframe['Punctuations'], self.dataframe['Punctuations Frequency']
        # return self.dataframe  # return a data frame of punctuation and its frequencies
