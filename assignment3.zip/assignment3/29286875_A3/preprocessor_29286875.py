"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         13, May
The last modified date: 13, May
Objective:      <<Setting up the preprocessor>>
                The function tokenise is to read a file; the function
                get_tokenised_list is to get a tokens list which contains
                all the words of the input file. That is, this class is used
                to analyse entire words and the total numbers of a file.
"""


class Preprocessor(object):
    """Setting up the preprocessor"""

    def __init__(self):
        """constructor for creating instances of this class"""
        self.token_hold = []  # a list to hold the individual tokens of a given input text
        self.items = []  # initiate a list to place no repeating characters
        self.count = []  # initiate a list to count

    def __str__(self):
        """present the readable total number of tokens for the tokenised input text"""

        total = len(self.token_hold)  # display the total numbers of the text
        return str(total)  # return the number

    def tokenise(self, input_sequence):
        """splits a given input text into individual tokens"""

        file_read = open(input_sequence, 'r')  # open the file
        for line in file_read:  # read each line of the file
            temp = line.split()  # split each line into separated words
            for each in temp:  # each separated words in temp
                self.token_hold.append(each)  # append into token_hold

        file_read.close()  # close the file

    def get_tokenised_list(self):
        """return the tokenised list"""

        for each in self.token_hold:  # remove repeating values
            if each not in self.items:  # check if exist in the list
                self.items.append(each)  # put into the list

        # make the size of the count list as same as the item list
        self.count = [0] * len(self.items)

        for each in self.token_hold:  # count the occurrences of each word
            self.count[self.items.index(each)] += 1

        return self.token_hold  # return token_hold (a list)


