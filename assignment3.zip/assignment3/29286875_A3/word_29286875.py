"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         13, May
The last modified date: 13, May
Objective:      <<Building a class for analysing words>>
                Class WordAnalyser is used to analyse words. A tokenised list would
                be examined and be returned by function analyse_words. Also, there are
                two main functions analysing stopwords and words lengths respectively.
"""


from preprocessor_29286875 import Preprocessor
from character_29286875 import CharacterAnalyser
from bs4 import BeautifulSoup
import requests
import pandas as pd


class WordAnalyser(object):
    """Building a class for analysing words"""

    def __init__(self):
        """define a data structure for storing each word frequency"""
        self.dataframe = pd.DataFrame()  # initiate a data frame
        self.word_list = []  # initiate a list maintaining words
        self.count_word = []  # initiate a list for counting words
        self.user_input = []  # initiate a list for place user input
        self.preprocessor = Preprocessor()  # initiate Preprocessor class
        # initiate the number of total texts
        self.total = len(self.preprocessor.get_tokenised_list())

    def __str__(self):
        """present the readable number of occurrences for each word"""

        # construct a data frame for words and its frequencies
        dataframe = {'Words': self.word_list, 'Frequency': self.count_word}
        self.dataframe = pd.DataFrame(dataframe, index=self.word_list, columns=['Frequency'])

        return print(self.dataframe)  # return a data frame of words and its frequencies

    def analyse_words(self, tokenised_list):
        """analyse and count the occurrences for each of the words"""
        self.total = len(tokenised_list)  # get the length of the text

        self.user_input = tokenised_list  # put user input into an instance variable list

        for each_word in tokenised_list:  # each word in tokenised_list
            if each_word not in self.word_list:  # check if each word in word_list
                self.word_list.append(each_word)  # if not, append it

        # make the size of count_word as same as word_list
        self.count_word = [0] * len(self.word_list)

        for each in tokenised_list:  # each character in tokenised_list
            self.count_word[self.word_list.index(each)] += 1  # count the occurrences of each word

        return self.word_list, self.count_word  # return 2 lists

    def get_stopword_frequency(self):
        """return only the frequency of stopwords or function words"""

        # grasp all stopwords from the particular link
        link = "http://www.lextek.com/manuals/onix/stopwords1.html"
        f = requests.get(link)  # request to get the link from the internet
        soup = BeautifulSoup(f.text, "html.parser")  # grasp words on the web page
        split_list = []  # list to store body text
        for each in soup.find_all('pre'):  # only grasp the body part of text
            split_list = each.text.split("\n")  # split each of them and put into a list
        index_a = split_list.index("a")  # take the value start from value 'a' in the list
        stopword_text = split_list[index_a:]  # value from 'a' to the end
        only_stopword = []  # list to store only stopword
        for each in stopword_text:  # each in stopword_text
            if each != '':  # do not take any space
                only_stopword.append(each)  # append each value into only_stopword

        # make the size of count_stopwords as same as stopwords_list
        count_stopwords = [0] * len(only_stopword)

        for word in self.user_input:  # each word in user_input(tokenised_list)
            for each in only_stopword:  # each stopword in stopwords_list
                if word == each:  # compare if these two are match
                    # count the occurrences of each stopword
                    count_stopwords[only_stopword.index(each)] += 1

        rela_stopword = []  # create a relative frequency list
        for each in count_stopwords:
            # calculate and append to rela_word_length
            rela_stopword.append(100 * (each / self.total))

        # construct a data frame for stopwords and its frequencies
        dataframe = {'Stopwords': only_stopword, 'Stopwords Frequency': rela_stopword}
        self.dataframe = pd.DataFrame(dataframe)

        return self.dataframe['Stopwords'], self.dataframe['Stopwords Frequency']  # return 2 lists

    def get_word_length_frequency(self):
        """return the number of occurrences for same-length words"""

        length_list = []  # create a non-repeating list
        word_len = []  # create a word-length list

        for each in self.word_list:  # each word in word_list
            word_len.append(len(each))  # first determine all the different word lengths
            for each_len in word_len:  # each length in word_len
                if each_len not in length_list:  # remove repeating length
                    length_list.append(each_len)

        length_list.sort()  # sort the length list

        # make the size of count_length as same as length_list
        count_length = [0] * len(length_list)

        for w_length in word_len:  # each word length in word_len
            for each_len in length_list:  # each sorted length in length_list
                if w_length == each_len:  # if they are the same
                    # count the occurrences of each length
                    count_length[length_list.index(each_len)] += 1

        rela_word_length = []  # create a relative frequency list
        for each in count_length:
            # calculate and append to rela_word_length
            rela_word_length.append(100 * (each / self.total))

        dataframe = {'Lengths': length_list, 'Lengths Frequency': rela_word_length}
        self.dataframe = pd.DataFrame(dataframe)

        return self.dataframe['Lengths'], self.dataframe['Lengths Frequency']  # return 2 lists
