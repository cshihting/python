"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         16, May
The last modified date: 24, May
Objective:      <<Putting all the classes together>>
                The main program enables the user to compare the different
                stylistic features analysed from the six selected texts
                authored by Shakespeare and Marlowe.
"""


from preprocessor_29286875 import Preprocessor
from visualiser_29286875 import AnalysisVisualiser
import matplotlib.pyplot as plt


# create a function for all analysis
def main():
    """execution of the program"""

    colors = ['b', 'g', 'r', 'c', 'm', 'y', 'k', 'w']  # a list for different colors

    flag = True
    while flag:

        # the rule for analysing texts
        print("\n\n" + 32 * "=" + " Stylometric Analyser " + 32 * "=" +
              "\nThis game enables you to compare the different stylistic features analysed\n"
              "from the six selected texts authored by Shakespeare and Marlowe.\n" +
              ">>>>> Follow the steps below to start the game:\n" +
              "     (1) Firstly, you should choose an option for analysing the text.\n" +
              "     (2) Secondly, enter how many files you want to analyse.\n" +
              "     (3) Then, input the correct and existing file name.\n" +
              "     (4) In the end, the specific analysis result would be screened.\n" +
              "      \n[In characters and punctuations analysis, the frequency would be \n" +
              "      displayed with scatter dots on one graph ; in stopwords and \n" +
              "      words length analysis, the analysis result will be drawn \n" +
              "      with lines on one graph.]\n" +
              "      \nHere are six texts here for analysing: \n" +
              "      1. Edward_II_Marlowe.tok\n" +
              "      2. Henry_VI_Part1_Shakespeare.tok\n" +
              "      3. Henry_VI_Part2_Shakespeare.tok\n" +
              "      4. Hamlet_Shakespeare.tok\n" +
              "      5. Jew_of_Malta_Marlowe.tok\n" +
              "      6. Richard_II_Shakespeare.tok")

        print_menu()  # display options
        choice = input("Enter your choice [1-5]: ")  # let the user input the option

        if choice == "1":  # the option 1: Characters Analysis
            while True:  # start while loop
                try:  # check if input without ValueError
                    file_num = int(input("How many files you want to read: "))  # let user input something
                except ValueError:  # if there is any ValueError
                    print("That was no valid number.  Try again...")  # prompt error
                else:  # if a valid input
                    for each in range(file_num):
                        user_ipnut, file_name = read_input()  # get return values from read_input()
                        analysis_visual = AnalysisVisualiser(user_ipnut)  # read input
                        # analyse characters frequency
                        char_list, rela_list = analysis_visual.visualise_character_frequency()
                        # plot with 'scatter' kind and set color & label
                        plt.scatter(char_list, rela_list, color=colors[each], label=file_name)
                    plt.title("Frequency of Characters")  # set title
                    plt.xlabel("Characters")  # set x label
                    plt.ylabel("Relative Frequency (%)")  # set y label
                    plt.legend(loc="upper right")  # set legend location
                    plt.show()  # show the graph
                    break  # terminate the while loop

        elif choice == "2":  # the option 2: Punctuations Analysis
            while True:  # start while loop
                try:  # check if input without ValueError
                    file_num = int(input("How many files you want to read: "))  # let user input something
                except ValueError:  # if there is any ValueError
                    print("That was no valid number.  Try again...")  # prompt error
                else:  # if a valid input
                    for each in range(file_num):
                        user_ipnut, file_name = read_input()  # get return values from read_input()
                        analysis_visual = AnalysisVisualiser(user_ipnut)  # read input
                        # analyse punctuations frequency
                        punc_list, rela_list = analysis_visual.visualise_punctuation_frequency()
                        # plot with 'scatter' kind and set color & label
                        plt.scatter(punc_list, rela_list, color=colors[each], label=file_name)
                    plt.title("Frequency of Punctuations")  # set title
                    plt.xlabel("Punctuations")  # set x label
                    plt.ylabel("Relative Frequency (%)")  # set y label
                    plt.legend(loc="upper right")  # set legend location
                    plt.show()  # show the graph
                    break  # terminate the while loop

        elif choice == "3":  # the option 3: Stopwords Analysis
            while True:  # start while loop
                try:  # check if input without ValueError
                    file_num = int(input("How many files you want to read: "))  # let user input something
                except ValueError:  # if there is any ValueError
                    print("That was no valid number.  Try again...")  # prompt error
                else:  # if a valid input
                    for each in range(file_num):
                        user_ipnut, file_name = read_input()  # get return values from read_input()
                        analysis_visual = AnalysisVisualiser(user_ipnut)  # read input
                        # analyse stopwords frequency
                        stopword_list, rela_list = analysis_visual.visualise_stopword_frequency()
                        # plot with 'line' kind and set color & label
                        plt.plot(stopword_list, rela_list, color=colors[each], label=file_name)
                    plt.title("Frequency of Stopwords")  # set title
                    plt.xlabel("Stopwords")  # set x label
                    plt.ylabel("Relative Frequency (%)")  # set y label
                    plt.legend(loc="upper right")  # set legend location
                    plt.show()  # show the graph
                    break  # terminate the while loop

        elif choice == "4":  # the option 4: Words Lengths Analysis
            while True:  # start while loop
                try:  # check if input without ValueError
                    file_num = int(input("How many files you want to read: "))  # let user input something
                except ValueError:  # if there is any ValueError
                    print("That was no valid number.  Try again...")  # prompt error
                else:  # if a valid input
                    for each in range(file_num):
                        user_ipnut, file_name = read_input()  # get return values from read_input()
                        analysis_visual = AnalysisVisualiser(user_ipnut)  # read input
                        # analyse words lengths frequency
                        wordlen_list, rela_list = analysis_visual.visualise_word_length_frequency()
                        # plot with 'line' kind and set color & label
                        plt.plot(wordlen_list, rela_list, color=colors[each], label=file_name)
                    plt.title("Frequency of Words Lengths")  # set title
                    plt.xlabel("Words Lengths")  # set x label
                    plt.ylabel("Relative Frequency (%)")  # set y label
                    plt.legend(loc="upper right")  # set legend location
                    plt.show()  # show the graph
                    break  # terminate the while loop

        elif choice == "5":  # the option 5: Exit
            print("Bye~")
            flag = False  # end the option

        else:
            # any integer inputs other than values 1-5 we print an error message
            input("Wrong option selection.\n\n")


# menu design
def print_menu():
    print(28 * "-" + " Options " + 28 * "-")
    print("1. Characters Analysis")  # 6 texts characters analysis
    print("2. Punctuations Analysis")  # 6 texts punctuations analysis
    print("3. Stopwords Analysis")  # 6 texts stopwords analysis
    print("4. Words Lengths Analysis")  # 6 texts words lengths analysis
    print("5. Exit")  # exit the game
    print(67 * "-")


def read_input():
    """read in each of the six input texts"""

    preprocessor = Preprocessor()

    while True:
        # let user input the file name
        user_input = input("Please input the text here: ")
        try:
            open(user_input, 'r')  # try if the file exists
        except IOError:  # if not exists, show the error
            print("Cannot find the file")
        else:  # if exists
            preprocessor.tokenise(user_input)
            return user_input, str(user_input)


# set the special __name__ variable to have a value '__main__'
# (if this file is being imported from another module, __name__ will be set to the module's name.)
if __name__ == '__main__':
    main()

