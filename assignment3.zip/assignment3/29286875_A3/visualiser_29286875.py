"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         14, May
The last modified date: 19, May
Objective:      <<Building a class for visualising the analysis>>
                This class is used to present four stylistic features.
"""


from preprocessor_29286875 import Preprocessor
from character_29286875 import CharacterAnalyser
from word_29286875 import WordAnalyser
import pandas as pd


class AnalysisVisualiser(object):
    """Building a class for visualising the analysis"""

    def __init__(self, all_text_stats):
        """define and initialise a data structure"""
        self.dataframe = pd.DataFrame()  # initiate a data frame
        self.preprocessor = Preprocessor()  # initiate Preprocessor class
        self.char_analysis = CharacterAnalyser()  # initiate CharacterAnalyser class
        self.word_analysis = WordAnalyser()  # initiate WordAnalyser class
        self.preprocessor.tokenise(all_text_stats)  # initiate tokenise function

    def visualise_character_frequency(self):
        """plot a graph to present the relative frequencies of each different character"""

        # get 2 lists from analyse_characters
        tokens_list = self.preprocessor.get_tokenised_list()
        char_list, rela_list = self.char_analysis.analyse_characters(tokens_list)
        return char_list, rela_list  # return 2 lists

    def visualise_punctuation_frequency(self):
        """plot a graph to present the relative frequencies of each different punctuation"""

        # get 2 lists from analyse_characters
        self.char_analysis.analyse_characters(self.preprocessor.get_tokenised_list())
        punc_list, rela_list = self.char_analysis.get_punctuation_frequency()
        return punc_list, rela_list  # return 2 lists

    def visualise_stopword_frequency(self):
        """plot a graph to present the relative frequencies of each different stopword"""

        # get 2 lists from analyse_words
        self.word_analysis.analyse_words(self.preprocessor.get_tokenised_list())
        stopword_list, rela_list = self.word_analysis.get_stopword_frequency()
        return stopword_list, rela_list  # return 2 lists

    def visualise_word_length_frequency(self):
        """plot a graph to present the relative frequencies of each different word"""

        # get 2 lists from analyse_words
        self.word_analysis.analyse_words(self.preprocessor.get_tokenised_list())
        wordlen_list, rela_list = self.word_analysis.get_word_length_frequency()
        return wordlen_list, rela_list  # return 2 lists
