"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         13, March
The last modified date: 15, March
Objective:              Count the occurrences of the user's input.
"""

# Build a Dictionary of Morse Code
MORSE_CODE_DICT = {'A': '01', 'B': '1000', 'C': '1010', 'D': '100',
                   'E': '0', 'F': '0010', 'G': '110', 'H': '0000',
                   'I': '00', 'J': '0111', 'K': '101', 'L': '0100',
                   'M': '11', 'N': '10', 'O': '111', 'P': '0110',
                   'Q': '1101', 'R': '010', 'S': '000', 'T': '1',
                   'U': '001', 'V': '0001', 'W': '011', 'X': '1001',
                   'Y': '1011', 'Z': '1100',

                   '0': '11111', '1': '01111', '2': '00111', '3': '00011',
                   '4': '00001', '5': '00000', '6': '10000', '7': '11000',
                   '8': '11100', '9': '11110'}

# Reverse the users' input.
# value:key(reverse); for...(loop)
MORSE_CODE_DICT_RESERVED = {value: key for key, value in MORSE_CODE_DICT.items()}


def from_morse(input_here):
    """gain the value from the dictionary"""
    return "".join(MORSE_CODE_DICT_RESERVED.get(i) for i in input_here.split("*"))  # return a str


def decode_morse_code(input_here):
    """decode the user's input"""
    if input_here != "":
        print("Your input is: " + input_here)

        # Put user_input to a list to check each index easily later.
        split_user_input_list = list(input_here.split("*"))

        valid_list = []  # valid values
        invalid_list = []  # invalid values
        morse_code = ""  # decoded codes
        # Define a string of all the characters in the English alphabet.
        alphabet_and_number = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        # Make the size of the count list as same as alphabet_and_number
        count = [0]*len(alphabet_and_number)

        # Define a list for each character in the English alphabet and number 0-9.
        items = []

        for letter in alphabet_and_number:
            items.append(letter)

        # Check each value in the split_user_input_list was in MORSE_CODE_DICT or not.
        for s_index in split_user_input_list:
            if s_index in MORSE_CODE_DICT.values():
                valid_list.append(s_index)
            else:
                invalid_list.append(s_index)

        # If there was no any invalid code, it would transfer the code.
        if not invalid_list:
            print("*Valid input: " + str(valid_list) +
                  " ,and in the morse code of this input means: " + from_morse(input_here))
            for character in from_morse(input_here):
                count[items.index(character)] += 1

            # To print out the result of counting.
            i = 0
            while i < len(items):
                if count[i] != 0:  # Just print the exist values
                    print(items[i] + ":" + str(count[i]))
                i += 1

        # If there was any invalid code inside...
        else:
            for m_index in valid_list:
                morse_code += from_morse(m_index)
            # No any valid input.
            if not valid_list:
                print("*Invalid input: " + str(invalid_list))
            # Display the valid and invalid respectively, also transfer the valid one.
            else:
                print("*Valid input: " + str(valid_list) +
                      " ,and in the morse code of this input means: " + morse_code)
                print("*Invalid input: " + str(invalid_list))

    # If the user didn't input anything.
    else:
        print("\nPlease input a number, a sign, or a letter at least.")


RUN = 0
while RUN == 0:
    USER_INPUT = input("----------------------------\n"
                       "----------------------------\nPlease input the code here: ")
    decode_morse_code(USER_INPUT)

    # Check if the user wanted to play again or not.
    if input("\nDo you want to continue the game? (y: yes)") == "y":
        print("Let's play again!!")
    else:
        print("Bye~")
        break  # terminate

