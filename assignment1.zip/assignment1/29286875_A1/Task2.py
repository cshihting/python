"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         13, March
The last modified date: 14, March
Objective:              Read the user's input.
"""

# Build a Dictionary of Morse Code.
MORSE_CODE_DICT = {'A': '01', 'B': '1000', 'C': '1010', 'D': '100',
                   'E': '0', 'F': '0010', 'G': '110', 'H': '0000',
                   'I': '00', 'J': '0111', 'K': '101', 'L': '0100',
                   'M': '11', 'N': '10', 'O': '111', 'P': '0110',
                   'Q': '1101', 'R': '010', 'S': '000', 'T': '1',
                   'U': '001', 'V': '0001', 'W': '011', 'X': '1001',
                   'Y': '1011', 'Z': '1100',

                   '0': '11111', '1': '01111', '2': '00111', '3': '00011',
                   '4': '00001', '5': '00000', '6': '10000', '7': '11000',
                   '8': '11100', '9': '11110'}


def read_user_input(input_here):
    """read the user's input"""
    if input_here != "":

        valid_list = []
        invalid_list = []

        # Split user input by "*" and place into a list.
        split_user_input_list = list(input_here.split("*"))

        # Check each value in the split_user_input_list was in MORSE_CODE_DICT or not.
        for s_index in split_user_input_list:
            if s_index in MORSE_CODE_DICT.values():
                valid_list.append(s_index)
            else:
                invalid_list.append(s_index)

        # If there was no any invalid code, the code would be transferred.
        if not invalid_list:
            print("Valid input: " + str(valid_list))

        # If there was any invalid code inside...
        else:
            # No any valid input.
            if not valid_list:
                print("*Invalid input: " + str(invalid_list))
            # Display the valid and invalid respectively.
            else:
                print("*Valid input: " + str(valid_list))
                print("*Invalid input: " + str(invalid_list))

    # If the user didn't input anything.
    else:
        print("\nPlease input a number, a sign, or a letter at least.")


RUN = 0
while RUN == 0:
    USER_INPUT = input("----------------------------\n"
                       "----------------------------\nPlease input the code here: ")

    # Place the list into the reading function.
    read_user_input(USER_INPUT)

    # Check if the user wanted to play again or not.
    if input("\nDo you want to continue the game? (y: yes)") == "y":
        print("Let's play again!!")
    else:
        print("Bye~")
        break  # terminate
