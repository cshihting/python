"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         25, April
The last modified date: 25, April
Objective:              << Building a class for analysing decoded characters >>
                        This class is for analysing the number of occurrences for
                        each of the letters (i.e. ‘A’ to ‘Z) and numerals (i.e. ‘0’ to ‘9’)
                        from the decoded sequences.
"""
from decoder_29286875 import Decoder  # import the class from decoder_29286875.py


# create a class for analysing decoded characters
class CharacterAnalyser(object):
    def __init__(self):  # 'self' is the keyword to the object
        """initialise some arguments"""
        self.from_decoder = Decoder()
        # define a string of all English alphabet, number 0-9 and punctuation characters
        self.alphabet_and_number = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,?"
        # make the size of the count list as same as alphabet_and_number
        self.count = [0] * len(self.alphabet_and_number)
        # define a list for each character in the English alphabet, number 0-9 and punctuation characters
        self.items = []

    def analyse_characters(self, decoded_sequence):
        """analyze characters occurrences"""

        for letter in self.alphabet_and_number:
            self.items.append(letter)

        for each in decoded_sequence:
            if each in self.items:
                self.count[self.items.index(each)] += 1

        return self.__str__()  # return a readable format

    def __str__(self):
        """present the number of occurrences for each of the letters and numerals"""
        # print out the result of counting.
        occurrence_result = ""
        i = 0
        while i < len(self.items):
            if self.count[i] != 0:  # just print the exist values
                occurrence_result += "  " + self.items[i] + " : " + str(self.count[i]) + "\n"
            i += 1
        return occurrence_result
