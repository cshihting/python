"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         27, April
The last modified date: 27, April
Objective:              << Putting all the classes together >>
                        This is a game letting an user to choose the specific decoded method.
                        In the beginning, the user should choose an option from the menu.
                        Then, the user will get the decoded result depending on the chosen choice.
                        In the end, the user will be asked to replay or exit the game.
"""

# import classes from other files
from decoder_29286875 import Decoder
from character_29286875 import CharacterAnalyser
from word_29286875 import WordAnalyser
from sentence_29286875 import SentenceAnalyser


# menu design
def print_menu():
    print(30 * "-" + " MENU " + 30 * "-")
    print("1. Characters Analysis")
    print("2. Words Analysis")
    print("3. Sentences Analysis")
    print("4. Exit")
    print(67 * "-")


# create a function for all analysis
def main():
    loop = True
    while loop:
        decode_class = Decoder()
        # the rule of the morse code game
        print("\n\n" + 30 * "=" + " Morse Code Decoder " + 30 * "=" +
              "\nWelcome to the Morse Code Decoder game!!!\n" +
              "Follow the steps below to start the game.\n\n" +
              "(1) Firstly, choose a method of decoding from the menu.\n" +
              "(2) Then, input the sequences of Morse Code you want. (at least a set of \"***\")\n" +
              "(3) In the end, you would get the decoded result and the analysis.\n\n")

        print_menu()  # displays menu
        choice = input("Enter your choice [1-4]: ")  # let the user input the option

        if choice == "1":  # the option 1: characters analysis
            char_analyser = CharacterAnalyser()  # create a constructor

            user_input = input("\nPlease input the sequences of Morse Code here: ")
            decoded_string = decode_class.decode(user_input)  # invoke the class Decode() to decode
            if decoded_string == "error":  # check if the user's input is invalid
                print("Replay the game.")
            elif decoded_string == "none":  # check if the user input something
                print("Replay the game.")
            elif decoded_string == "***":  # check if the input is a full sentence
                print("Replay the game.")
            else:
                print("* Your input: " + decoded_string + "\n")  # display the decoded result
                # display the character occurrences
                print("* The result of characters analysis:\n" + str(char_analyser.analyse_characters(decoded_string)))

        elif choice == "2":  # the option 2: words analysis
            word_analyser = WordAnalyser()  # create a constructor

            user_input = input("\nPlease input the sequences of Morse Code here: ")
            decoded_string = decode_class.decode(user_input)  # invoke the class Decode() to decode
            if decoded_string == "error":  # check if the user's input is invalid
                print("Replay the game.")
            elif decoded_string == "none":  # check if the user input something
                print("Replay the game.")
            elif decoded_string == "***":  # check if the input is a full sentence
                print("Replay the game.")
            else:
                print("* Your input: " + decoded_string + "\n")  # display the decoded result
                # display the words occurrences
                print("* The result of words analysis:\n" + str(word_analyser.analyse_words(decoded_string)))

        elif choice == "3":  # the option 3: sentences analysis
            sentence_analyser = SentenceAnalyser()  # create a constructor

            user_input = input("\nPlease input the sequences of Morse Code here: ")
            decoded_string = decode_class.decode(user_input)  # invoke the class Decode() to decode
            if decoded_string == "error":  # check if the user's input is invalid
                print("Replay the game.")
            elif decoded_string == "none":  # check if the user input something
                print("Replay the game.")
            elif decoded_string == "***":  # check if the input is a full sentence
                print("Replay the game.")
            else:
                print("* Your input: " + decoded_string + "\n")  # display the decoded result
                # display the sequences occurrences
                print("* The result of words analysis:\n" + str(sentence_analyser.analyse_sentences(decoded_string)))

        elif choice == "4":  # the option 4: exit
            print("Bye~")
            loop = False  # end the option

        else:
            # any integer inputs other than values 1-4 we print an error message
            input("Wrong option selection. Enter the key on the menu to try again...\n\n")


# set the special __name__ variable to have a value '__main__'
# (if this file is being imported from another module, __name__ will be set to the module's name.)
if __name__ == '__main__':
    main()
    main()

