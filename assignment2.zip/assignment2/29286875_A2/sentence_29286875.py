"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         26, April
The last modified date: 26, April
Objective:              << Building a class for analysing decoded sentences >>
                        This class is for analysing the number of occurrences
                        for each type of English sentences from the decoded sequences.

                        The types of sentence include:
                        clauses (","), complete sentences ("."), and questions ("?").

                        In this code, it will just display "," as clauses, "." as complete
                        sentences and "?" as questions.
"""
from decoder_29286875 import Decoder  # import the class from decoder_29286875.py


# create a class for analysing decoded sentences
class SentenceAnalyser(object):
    def __init__(self):  # 'self' is the keyword to the object
        """initialise some arguments"""
        self.from_decoder = Decoder()
        self.items = [".", ",", "?"]
        self.count = [0] * 3
        self.character = []  # a list for three-star-split values (***)

    def analyse_sentences(self, decoded_sequence):
        """analyze sentences occurrences"""

        result_split_list = []  # a list for putting split values

        for each in decoded_sequence.split(" "):  # split result by a space
            result_split_list.append(each)  # put all split values into the list

        whatever_list = []  # a list for putting non-punctuation characters
        for each in result_split_list:  # count the occurrence of each punctuation characters
            if each == ".":
                self.count[self.items.index(each)] += 1
            elif each == ",":
                self.count[self.items.index(each)] += 1
            elif each == "?":
                self.count[self.items.index(each)] += 1
            else:
                whatever_list.append(each)

        return self.__str__()  # return a readable format

    def __str__(self):
        """present the number of occurrences for each sentence type"""
        # to print out the result of counting.
        occurrence_result = ""
        i = 0
        while i < len(self.items):
            occurrence_result += "  (" + str(i+1) + ") Sentence types \'" + \
                                 self.items[i] + "\' : " + str(self.count[i]) + "\n"
            i += 1
        return occurrence_result
