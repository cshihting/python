"""
Name:                   Shih Ting Chu
ID:                     29286875
The Start date:         18, April
The last modified date: 25, April
Objective:              << Building a class for Morse Code decoder >>
                        This decoder class is used for decoding any Morse Code sequences.
                        Also, the Morse Code sequences will terminate with one of the three punctuation characters,
                        i.e. the period ‘.’; the comma ‘,’; and the question mark ‘?’.
"""


# create a decode class
class Decoder(object):
    def __init__(self):  # 'self' is the keyword to the object
        """define and initialise the dictionary structure"""
        # build a Dictionary of Morse Code
        self.morseCodeDict = {'A': '01', 'B': '1000', 'C': '1010', 'D': '100',
                              'E': '0', 'F': '0010', 'G': '110', 'H': '0000',
                              'I': '00', 'J': '0111', 'K': '101', 'L': '0100',
                              'M': '11', 'N': '10', 'O': '111', 'P': '0110',
                              'Q': '1101', 'R': '010', 'S': '000', 'T': '1',
                              'U': '001', 'V': '0001', 'W': '011', 'X': '1001',
                              'Y': '1011', 'Z': '1100',

                              '0': '11111', '1': '01111', '2': '00111', '3': '00011',
                              '4': '00001', '5': '00000', '6': '10000', '7': '11000',
                              '8': '11100', '9': '11110',

                              '.': '010101', ',': '110011', '?': '001100'}
        # reverse the user's input
        # value:key(reverse); for...(loop)
        self.morseCodeDictReserve = {code: character for character, code in self.morseCodeDict.items()}
        self.character = []  # a list for three-star-split values (***)

    def __str__(self):
        """present the readable Morse code representation table"""
        dict_table = ""
        for key, value in self.morseCodeDict.items():
            dict_table += key + " : " + self.morseCodeDict[key] + "\n"
        return dict_table

    def from_morse(self, morse_code_sequence):
        """gain the value from the dictionary"""
        return "".join(self.morseCodeDictReserve.get(each) for each in morse_code_sequence.split("*"))

    def decode(self, morse_code_sequence):
        """performs the decoding process"""
        if morse_code_sequence != "":

            split_character = []  # a list for one-star-split values (*)
            word_character = []  # [[], [], []]
            for each in morse_code_sequence.split("***"):  # split by ***
                self.character.append(each)  # append each value to character

            if len(self.character) == 1:
                print("\nYou should input a complete sentence.\n" +
                      "(The sequence must include one set of three consecutive ‘*’ at least.)")
                return "***"  # return the string "***" to check

            else:
                for each_word in self.character:
                    for each_char in each_word.split("*"):  # split by *
                        split_character.append(each_char)  # append each value to split_character
                    word_character.append(split_character)  # append each value to word_character
                    split_character = []  # clear values, and then reuse

                invalid_list = []  # place invalid values

                # check each value in the word_character was in morseCodeDict or not
                for each_word in word_character:
                    for each_char in each_word:
                        if each_char not in self.morseCodeDict.values():
                            invalid_list.append(each_char)

                result = ""
                # if there was no any invalid code, it would transfer the code
                if not invalid_list:
                    for each_word in word_character:
                        for each_char in each_word:
                            result += self.from_morse(each_char)  # add the decoded characters into a string
                        result += " "  # put a space between two words
                    return result  # return the string result

                # if there was any invalid code inside...
                else:
                    print("* ERROR!!! Invalid input: " + str(invalid_list))
                    return "error"  # return the string "error" to check

        # if the user didn't input anything
        else:
            print("\nPlease input a number, a sign, or a letter at least.")
            return "none"  # return the string "none" to check
